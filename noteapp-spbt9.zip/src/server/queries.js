import HttpError from '@wasp/core/HttpError.js'

export const getNotes = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  return context.entities.Note.findMany({
    where: {
      userId: context.user.id
    }
  });
}

export const getNote = async ({ id }, context) => {
  if (!context.user) { throw new HttpError(401) };

  const note = await context.entities.Note.findUnique({
    where: { id },
    include: { user: true }
  });

  if (!note) { throw new HttpError(404, `Note with id ${id} not found`) };

  return note;
}